package application;

import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

abstract class plants {
	protected String type;
	protected int power;
	protected int positionx;
	public Pane workingpane=new Pane();
	public Pane getWorkingpane() {
		return workingpane;
	}
	public void setWorkingpane(Pane workingpane) {
		this.workingpane = workingpane;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getPower() {
		return power;
	}
	abstract void attack(ArrayList<zombies> a);
	public void setPower(int power) {
		this.power = power;
	}
	public int getPositionx() {
		return positionx;
	}
	public void setPositionx(int positionx) {
		this.positionx = positionx;
	}
	public int getPositiony() {
		return positiony;
	}
	public void setPositiony(int positiony) {
		this.positiony = positiony;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Image getImageofplant() {
		return Imageofplant;
	}
	public void setImageofplant(Image imageofplant) {
		Imageofplant = imageofplant;
	}
	protected int positiony;
	protected int price;
	protected Image Imageofplant;
	plants(String id,int power, int positionx,int positiony,int price,Image k){
		this.type=id;
		this.Imageofplant=k;
		this.power=power;
		this.positionx=positionx;
		this.positiony=positiony;
		this.price=price;
	}
}
class shooters extends plants{

	shooters(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price, k);
		// TODO Auto-generated constructor stub
	}

	@Override
	void attack(ArrayList<zombies> a) {
		// TODO Auto-generated method stub
		
	}
}
class normal_shooter extends shooters{

	normal_shooter(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price, k);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void attack(ArrayList<zombies> a1) {
		Circle cir=new Circle();
		cir.setRadius(12);
		cir.setFill(Color.LAWNGREEN);
		cir.setLayoutX(positionx+60);
		cir.setLayoutY(positiony+40);
		super.workingpane.getChildren().add(cir);
		TranslateTransition a=new TranslateTransition();
		a.setNode(cir);
		zombies temp=new shield_zombie(200,"shield_zombie",new ImageView(new Image("file:screen.png")));
		for(int i=0;i<a1.size();i++) {
			ImageView k=a1.get(i).ZombieImage;
			//System.out.println(cir.getLayoutX()+"   "+cir.getLayoutY());
			//System.out.println(k.getX()+"  :  "+k.getY());
			if(k.getY()>cir.getLayoutY()&(cir.getLayoutY()>k.getY()-100)) {
				temp=a1.get(i);
				//System.out.println(temp.type);
				break;
			}
		}
		if(temp.type.equals("shield_zombie")) {
			return ;
		}else {
		a.setByX(temp.ZombieImage.getX());
		//a.setCycleCount(Animation.INDEFINITE);
		a.setDuration(Duration.seconds(1));
		temp.health=temp.health-25;
		a.play();
		}
		if(temp.health<=0) {
			a1.remove(temp);
			super.workingpane.getChildren().remove(temp.ZombieImage);
		}
	}	
}
class triple_shooter extends shooters{

	triple_shooter(String id, int power, int positionx, int positiony, int price, Image k) {
		super(id, power, positionx, positiony, price, k);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void attack(ArrayList<zombies> a1) {
		Circle cir=new Circle();
		cir.setRadius(12);
		cir.setFill(Color.LAWNGREEN);
		cir.setLayoutX(positionx+60);
		cir.setLayoutY(positiony+40);
		//
		Circle cir2=new Circle();
		cir.setRadius(12);
		cir.setFill(Color.LAWNGREEN);
		cir.setLayoutX(positionx+60);
		cir.setLayoutY(positiony+40);
		super.workingpane.getChildren().add(cir);
		TranslateTransition a=new TranslateTransition();
		a.setNode(cir);
		zombies temp=a1.get(1);
		for(int i=0;i<a1.size();i++) {
			ImageView k=a1.get(i).ZombieImage;
			if(k.getY()>cir.getLayoutY()&(cir.getLayoutY()>k.getY()-100)) {
				temp=a1.get(i);
				System.out.println(temp.type);
				break;
			}
		}
		a.setByX(700);
		a.setCycleCount(Animation.INDEFINITE);
		a.setDuration(Duration.seconds(3));
		a.play();
	}	
	
}
class blockers extends plants{

	blockers(String id, int power, int positionx, int positiony, int price, Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}

	@Override
	void attack(ArrayList<zombies> a) {
		// TODO Auto-generated method stub
		System.out.println("blockerattack");
	}
	
}
class wallnut extends blockers{

	wallnut(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}
	
}
class bigwallnut extends blockers{

	bigwallnut(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}
	
}
class blasters extends plants{

	blasters(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}

	@Override
	void attack(ArrayList<zombies> a) {
		// TODO Auto-generated method stub
		System.out.println("blaster attack");
	}
	
}
class cherrybomb extends blasters{

	cherrybomb(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}
	@Override
	void attack(ArrayList<zombies> a1) {
		ImageView a=new ImageView(super.Imageofplant);
		a.setX(positionx);
		a.setY(positiony);
		super.workingpane.getChildren().add(a);
		ScaleTransition s1=new ScaleTransition();
		s1.setNode(a);
		s1.setDuration(Duration.seconds(1));
		s1.setToX(10);
		s1.setToY(10);
		s1.setToZ(10);
		//s1.setNode(a);
		s1.play();
	}
}
class potatomine extends blasters{

	potatomine(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}
	void attack(ArrayList<zombies> a) {
		// TODO Auto-generated method stub
	}
}
class sungivers extends plants{

	sungivers(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		
	}

	@Override
	void attack(ArrayList<zombies> a) {
		// TODO Auto-generated method stub
		System.out.println("sungiver give sun");
	}
	
}
class bigsungiver extends sungivers{

	bigsungiver(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}
	
}
class triplesungiver extends sungivers{

	triplesungiver(String id, int power, int positionx, int positiony, int price,Image k) {
		super(id, power, positionx, positiony, price,k);
		// TODO Auto-generated constructor stub
	}
	
}